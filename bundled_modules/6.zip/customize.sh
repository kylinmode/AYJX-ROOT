#!/system/bin/sh
# 安装时校验当前内核是否有对应的 ko，没有则提示内核版本不支持并中止安装。

# Magisk / KSU 安装器通常提供 ui_print 与 abort，缺失时用最小实现兜底。
# 注意不要写成 `cmd || fn() {...}`，部分 shell（mksh / busybox ash）对此有语法限制。
if ! command -v ui_print >/dev/null 2>&1; then
	ui_print() { echo "$*"; }
fi
if ! command -v abort >/dev/null 2>&1; then
	abort() { echo "! $*" >&2; exit 1; }
fi

# 变量统一加 PM_ 前缀：Magisk 会 source 本脚本，避免污染安装器环境。
PM_KMI_DIR="$MODPATH/ko"

PM_KVER=$(uname -r 2>/dev/null | cut -d. -f1,2)
PM_SDK=$(getprop ro.build.version.sdk 2>/dev/null)
case "$PM_SDK" in
	31|32) PM_AVAL=android12 ;;
	33) PM_AVAL=android13 ;;
	34) PM_AVAL=android14 ;;
	35) PM_AVAL=android15 ;;
	36) PM_AVAL=android16 ;;
	37) PM_AVAL=android17 ;;
	*) PM_AVAL=$(getprop ro.build.version.release 2>/dev/null | sed -n 's/^\([0-9]\{1,\}\).*/android\1/p') ;;
esac

PM_KMI=""
if [ -n "$PM_KVER" ] && [ -n "$PM_AVAL" ] && [ -f "$PM_KMI_DIR/${PM_AVAL}-${PM_KVER}_pathmask.ko" ]; then
	PM_KMI="${PM_AVAL}-${PM_KVER}"
else
	for pm_kmi_f in "$PM_KMI_DIR"/*-"${PM_KVER}"_pathmask.ko; do
		[ -f "$pm_kmi_f" ] || continue
		pm_kmi_f=${pm_kmi_f##*/}
		PM_KMI=${pm_kmi_f%_pathmask.ko}
		break
	done
fi

if [ -z "$PM_KMI" ]; then
	ui_print "! 内核版本不支持"
	ui_print "- 当前内核: $(uname -r 2>/dev/null)"
	ui_print "- 当前 Android: ${PM_AVAL:-unknown} (sdk ${PM_SDK:-unknown})"
	ui_print "- 本模块内置内核: 5.10 / 5.15 / 6.1 / 6.6 / 6.12 / 6.18"
	abort "安装已中止"
fi

ui_print "- 内核匹配: $PM_KMI"
if ! cp -f "$PM_KMI_DIR/${PM_KMI}_pathmask.ko" "$MODPATH/pathmask.ko"; then
	abort "释放 pathmask.ko 失败"
fi
# procguard.ko 缺失时不影响主模块，不能让脚本以非 0 状态结束导致安装失败。
if [ -f "$PM_KMI_DIR/${PM_KMI}_procguard.ko" ]; then
	cp -f "$PM_KMI_DIR/${PM_KMI}_procguard.ko" "$MODPATH/procguard.ko" || true
fi

# 安装完成后立即冻结 Soter 服务；设备上没有该包时静默跳过。
# 保持在脚本末尾且以 if 结尾，确保整体退出码为 0，不影响安装结果。
PM_SOTER_PKG=com.tencent.soter.soterserver
if command -v pm >/dev/null 2>&1; then
	pm disable-user --user 0 "$PM_SOTER_PKG" >/dev/null 2>&1 || true
fi
