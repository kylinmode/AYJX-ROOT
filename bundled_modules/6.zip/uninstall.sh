#!/system/bin/sh

LOG_TAG=pathmask
PERSIST_DIR="/data/adb/pathmask"

log_i() {
	log -p i -t "$LOG_TAG" "$*" 2>/dev/null
}

# Unload the kernel module if it's still in /proc/modules. KernelSU runs this
# script while the module folder is being removed; stop the kernel side first
# so we don't leave a dangling LKM behind.
if grep -q '^pathmask ' /proc/modules 2>/dev/null; then
	if rmmod pathmask 2>/dev/null; then
		log_i "rmmod pathmask succeeded"
	else
		log_i "rmmod pathmask failed; module will unload on next reboot"
	fi
fi

# Unload the procguard companion module if this build shipped one.
if grep -q '^procguard ' /proc/modules 2>/dev/null; then
	if rmmod procguard 2>/dev/null; then
		log_i "rmmod procguard succeeded"
	else
		log_i "rmmod procguard failed; module will unload on next reboot"
	fi
fi

# Drop the persistent config directory so a future fresh install starts from
# the zip-bundled defaults instead of inheriting stale UID lists, fail
# counters, boot_state, etc.
if [ -d "$PERSIST_DIR" ]; then
	rm -rf "$PERSIST_DIR" 2>/dev/null && \
		log_i "removed $PERSIST_DIR"
fi

# Restore the Soter service that service.sh / customize.sh froze. Under Magisk
# this script runs at post-fs-data on the next boot, where the package manager
# is not up yet, so a direct `pm enable` would fail. Drop a service.d script
# that retries during late_start and removes itself afterwards. Under KernelSU
# the package manager is already running, so enable it right away.
SOTER_PKG=com.tencent.soter.soterserver
if command -v pm >/dev/null 2>&1 && pm enable --user 0 "$SOTER_PKG" >/dev/null 2>&1; then
	log_i "re-enabled $SOTER_PKG"
else
	UNFREEZE_SCRIPT=/data/adb/service.d/pathmask_unfreeze_soter.sh
	if mkdir -p /data/adb/service.d 2>/dev/null; then
		cat > "$UNFREEZE_SCRIPT" <<'EOF'
#!/system/bin/sh
# Queued by the PathMask uninstall flow; enables Soter once the system is up.
i=0
while [ "$i" -lt 60 ]; do
	if pm list packages >/dev/null 2>&1; then
		pm enable --user 0 com.tencent.soter.soterserver >/dev/null 2>&1
		break
	fi
	sleep 2
	i=$((i + 1))
done
rm -f "$0"
EOF
		chmod 0755 "$UNFREEZE_SCRIPT" 2>/dev/null && \
			log_i "queued soter unfreeze at $UNFREEZE_SCRIPT"
	fi
fi
